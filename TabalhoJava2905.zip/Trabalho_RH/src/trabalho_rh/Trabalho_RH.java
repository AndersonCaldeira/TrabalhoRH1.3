/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho_rh;

import java.util.logging.Logger;

/**
 *
 * @author brend
 */
public class Trabalho_RH {

    /**
     *
     */
    
    public Trabalho_RH(){
       
    }
    
    
    public static void main(String[] args) {
       
       new frm_Inicio().setVisible(true); 
       
     
       
           }
       

    private static class barra_progresso {

        private static void setValue(int i) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        public barra_progresso() {
        }
    }
       
      
       
    }
    

